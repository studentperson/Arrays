#include <iostream>
#include "Array2.h"
#include "sort.h"

using namespace std;

int main()
{
    Array2 A(5);
    /*cout<<"Size :"<<A.getSize()<<endl;
    cout<<"Current array: "<<endl;
    A.displayArray();
    A.addToEnd(50);
    cout<<"Current array: "<<endl;
    A.displayArray();
    A.addToTop(30);
    cout<<"Current array: "<<endl;
    A.displayArray();
    A.removeFromTop();
    A.removeFromBottom();
    cout<<"Current array: "<<endl;
    A.displayArray();
    A.reverseArray();
    cout<<"Current array: "<<endl;
    A.displayArray();
    cout<<"Sum of the elements in the array: "<<A.returnSum()<<endl;
    //this is having some issues i suspect it has something to do with NULL values
    int *oNum;
    oNum = A.checkOdd();*/
    A.displayArray();
    cout<< "Now sort: "<<endl;
    //A.selectSort();
    //A.insertSort();
    //A.bubbleSort();
    //A.mergeSort(0, A.getSize());
    A.quickSort(0, A.getSize());
    A.displayArray();

    return 0;
}
