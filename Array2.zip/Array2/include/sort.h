#ifndef SORT_H
#define SORT_H
#include "Array2.h"


class sort
{
    public:
        sort();
        virtual ~sort();
        void sortPrint();

    protected:

    private:
};

#endif // SORT_H
