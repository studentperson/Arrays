#include "sort.h"
#include "Array2.h"

sort::sort()
{
    //ctor
}

sort::~sort()
{
    //dtor
}
