# Arrays
compile with
g++ Arrays2.h Arrays2.cpp main.cpp

Running the Bash program will run automated testing sequences that will gather and record the data needed for the report.

You can select what sorting algorithms and specify what sort of array you want use by specifying specific cases for the arrays and algorithms.

Norman Mamani Worked on the report and core code, He also put together the bash coded used to automate the testing sequences.
Andrew Schroepfer Worked on the core code and report.
